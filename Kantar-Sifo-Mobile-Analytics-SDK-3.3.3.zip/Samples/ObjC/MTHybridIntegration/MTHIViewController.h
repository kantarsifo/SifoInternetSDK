//
//  MTHIViewController.h
//  TSMobileTaggingIntegration
//
//  Copyright (c) 2016 TNS Sifo AB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTHIViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, UIWebViewDelegate>

@end
