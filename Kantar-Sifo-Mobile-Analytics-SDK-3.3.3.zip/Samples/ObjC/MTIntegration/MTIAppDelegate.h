
#import <UIKit/UIKit.h>

@class MTIViewController;

@interface MTIAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MTIViewController *viewController;

@end
